import { fmtET } from './time.js';

export async function sendTelegram(env, text) {
  const res = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: env.TELEGRAM_CHAT_ID, text, disable_web_page_preview: true }),
  });
  if (!res.ok) throw new Error(`Telegram HTTP ${res.status}: ${await res.text()}`);
}

const $ = (x) => `$${Number(x).toFixed(2)}`;

export function formatAlert(symbol, tf, strategy, sig, candleT) {
  const tag = sig.direction === 'CALL' ? '🟢 CALL — ENTRY' : '🔴 PUT — ENTRY';
  const strike = `${Math.round(sig.entry)}${sig.direction === 'CALL' ? 'C' : 'P'}`;
  const lines = [
    tag,
    '',
    `• Ticker: ${symbol}`,
    `• Strategy: ${strategy.name} (${tf})`,
    `• Entry: ${$(sig.entry)}`,
    `• Stop-loss: ${$(sig.stop)}`,
    `• Target: ${$(sig.target)}`,
    `• Strike (approx ATM): ${strike}`,
    `• Confidence: ${sig.confidence}`,
    `• Candle: ${fmtET(candleT)}`,
  ];
  if (sig.notes) lines.push(`• Info: ${sig.notes}`);
  lines.push('', '⚠️ Not financial advice — chart khud check karke trade lena.');
  return lines.join('\n');
}
