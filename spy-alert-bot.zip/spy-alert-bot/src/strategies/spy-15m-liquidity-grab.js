// SPY 15M Liquidity Grab — CALL / PUT (user ki strategy)
//
// CALL (sweep candle = pichhli candle, confirm = latest closed candle):
//  1. Liquidity Low   — sweep se pehle ke 20 completed bars ka lowest low
//  2. Liquidity Grab  — sweep candle ka low, liquidity low ke paas / neeche (tolerance ke andar)
//  3. RED rejection   — sweep candle red, close liquidity low ke upar
//  4. Next GREEN      — sweep ke baad wali candle green close
//  5. RSI UP          — current RSI > previous RSI
//  6. Volume Strong   — sweep candle volume > pichhle 20 bars ka average
//
// PUT (sweep candle = latest closed candle):
//  1. Liquidity High  — sweep se pehle ke 20 completed bars ka highest high
//  2. Liquidity Grab  — sweep candle ka high, liquidity high ko touch / penetrate kare
//  3. RED rejection   — sweep candle red, close liquidity high ke neeche
//  4. Next candle     — PUT ke liye hamesha TRUE (jaisa strategy mein diya hai)
//  5. RSI DOWN        — current RSI < previous RSI
//  6. Volume Strong   — sweep candle volume > pichhle 20 bars ka average
//
// 5/6 ya 6/6 → alert.  6/6 = High, 5/6 = Medium.

import { rsi, avgVolumeBefore } from '../indicators.js';

// ===== SETTINGS (yahan badal sakta hai) =====
const LOOKBACK = 20;          // liquidity level ke liye kitne bars
const RSI_PERIOD = 14;
const TOL_PCT = 0.0005;       // grab tolerance = price ka 0.05% (~$0.33 SPY 650 pe)
const MIN_SCORE = 5;          // 5/6 chahiye
const REQUIRE_GRAB = false;   // true = liquidity grab (check 2) compulsory
const STOP_BUFFER = 0.10;     // stop sweep wick se $0.10 aage
const RR = 2;                 // target = 2 × risk
// ============================================

const mark = (ok) => (ok ? '✅' : '❌');

function checkCall(bars, r) {
  const i = bars.length - 1;           // next (confirm) candle
  const s = i - 1;                     // sweep candle
  if (s - LOOKBACK < 0 || r[i] == null || r[i - 1] == null) return null;
  const sweep = bars[s], next = bars[i];

  const prior = bars.slice(s - LOOKBACK, s);
  const liqLow = Math.min(...prior.map(b => b.l));
  const tol = sweep.c * TOL_PCT;

  const c = {
    liq: Number.isFinite(liqLow),
    grab: sweep.l <= liqLow + tol,
    red: sweep.c < sweep.o && sweep.c > liqLow,
    green: next.c > next.o,
    rsi: r[i] > r[i - 1],
    vol: sweep.v > avgVolumeBefore(bars, s, LOOKBACK),
  };
  const score = Object.values(c).filter(Boolean).length;
  if (score < MIN_SCORE || (REQUIRE_GRAB && !c.grab)) return null;

  const entry = next.c;
  const stop = Math.min(sweep.l, next.l) - STOP_BUFFER;
  return {
    direction: 'CALL', score, entry, stop,
    target: entry + RR * (entry - stop),
    confidence: score === 6 ? 'High' : 'Medium',
    notes: `${score}/6 | ${mark(c.liq)} LiqLow ${liqLow.toFixed(2)} ${mark(c.grab)} Grab ` +
      `${mark(c.red)} Red rejection ${mark(c.green)} Next green ${mark(c.rsi)} RSI up ` +
      `(${r[i].toFixed(1)}) ${mark(c.vol)} Volume`,
  };
}

function checkPut(bars, r) {
  const i = bars.length - 1;           // sweep candle = latest closed
  if (i - LOOKBACK < 0 || r[i] == null || r[i - 1] == null) return null;
  const sweep = bars[i];

  const prior = bars.slice(i - LOOKBACK, i);
  const liqHigh = Math.max(...prior.map(b => b.h));
  const tol = sweep.c * TOL_PCT;

  const c = {
    liq: Number.isFinite(liqHigh),
    grab: sweep.h >= liqHigh - tol,
    red: sweep.c < sweep.o && sweep.c < liqHigh,
    next: true,
    rsi: r[i] < r[i - 1],
    vol: sweep.v > avgVolumeBefore(bars, i, LOOKBACK),
  };
  const score = Object.values(c).filter(Boolean).length;
  if (score < MIN_SCORE || (REQUIRE_GRAB && !c.grab)) return null;

  const entry = sweep.c;
  const stop = sweep.h + STOP_BUFFER;
  return {
    direction: 'PUT', score, entry, stop,
    target: entry - RR * (stop - entry),
    confidence: score === 6 ? 'High' : 'Medium',
    notes: `${score}/6 | ${mark(c.liq)} LiqHigh ${liqHigh.toFixed(2)} ${mark(c.grab)} Grab ` +
      `${mark(c.red)} Red rejection ✅ Next (auto) ${mark(c.rsi)} RSI down ` +
      `(${r[i].toFixed(1)}) ${mark(c.vol)} Volume`,
  };
}

export default {
  id: 'spy_15m_liq_grab',
  name: 'SPY 15M Liquidity Grab',
  timeframes: ['15m'],
  maxPerDay: 5,
  minConfidence: 'Medium',

  evaluate(bars) {
    if (bars.length < LOOKBACK + 3) return null;
    const r = rsi(bars.map(b => b.c), RSI_PERIOD);
    const call = checkCall(bars, r);
    const put = checkPut(bars, r);
    if (call && put) {                 // dono ek saath → jiska score zyada
      if (call.score === put.score) return null;
      return call.score > put.score ? call : put;
    }
    return call || put;
  },
};
