// ⚠️ EXAMPLE strategy — sirf dikhane ke liye ki strategy kaise likhte hain.
// Apni strategy bhej, main isko replace / naya file bana dunga.
//
// CALL: close > VWAP, EMA9 > EMA20, last 2 candles mein VWAP/EMA20 tak pullback,
//       RSI upar mud raha (aur 70 se neeche), bullish candle
// PUT : bilkul ulta
import { ema, rsi, vwap, atr, avgVolumeBefore } from '../indicators.js';

export default {
  id: 'ema_vwap_rsi',
  name: 'EMA+VWAP+RSI Pullback (example)',
  timeframes: ['5m', '15m', '1h'],   // kin timeframes pe chalana hai
  maxPerDay: 3,                      // har timeframe pe din mein max alerts
  minConfidence: 'Medium',           // isse kam wale alert nahi aayenge

  evaluate(bars) {
    if (bars.length < 50) return null;
    const closes = bars.map(b => b.c);
    const e9 = ema(closes, 9), e20 = ema(closes, 20);
    const r = rsi(closes, 14), vw = vwap(bars), a = atr(bars, 14);
    const i = bars.length - 1, b = bars[i], p = bars[i - 1];
    if ([e9[i], e20[i], r[i], r[i - 1], a[i]].some(x => x == null)) return null;

    const avgVol = avgVolumeBefore(bars, i, 20);
    const relVol = avgVol > 0 ? b.v / avgVol : 0;

    let direction = null, stop;
    const lowTouch = Math.min(b.l, p.l), highTouch = Math.max(b.h, p.h);

    if (b.c > vw[i] && e9[i] > e20[i] && lowTouch <= Math.max(e20[i], vw[i]) &&
        r[i] > r[i - 1] && r[i] < 70 && b.c > b.o) {
      direction = 'CALL';
      stop = lowTouch - 0.1 * a[i];
    } else if (b.c < vw[i] && e9[i] < e20[i] && highTouch >= Math.min(e20[i], vw[i]) &&
        r[i] < r[i - 1] && r[i] > 30 && b.c < b.o) {
      direction = 'PUT';
      stop = highTouch + 0.1 * a[i];
    }
    if (!direction) return null;

    const entry = b.c;
    const risk = Math.abs(entry - stop);
    const target = direction === 'CALL' ? entry + 2 * risk : entry - 2 * risk;

    let score = 0;
    if (relVol >= 1.2) score++;
    if (r[i] >= 40 && r[i] <= 60) score++;
    const confidence = score === 2 ? 'High' : score === 1 ? 'Medium' : 'Low';

    return {
      direction, entry, stop, target, confidence,
      notes: `RSI ${r[i].toFixed(1)} | RelVol ${relVol.toFixed(2)}x | VWAP ${vw[i].toFixed(2)}`,
    };
  },
};
