// Nayi strategy ka template. Copy karke naam badlo, phir strategies/index.js mein add karo.
// evaluate(bars) ko sirf CLOSED candles milti hain; last candle = bars[bars.length-1].
// Setup nahi bana → return null. Bana → return { direction, entry, stop, target, confidence, notes }.
import { ema, rsi, vwap, atr, sma, avgVolumeBefore, todaysBars } from '../indicators.js';

export default {
  id: 'my_strategy',          // unique, bina space
  name: 'My Strategy',
  timeframes: ['5m'],         // '5m' | '15m' | '1h' — ek ya zyada
  maxPerDay: 1,
  minConfidence: 'Medium',    // 'Low' | 'Medium' | 'High'

  evaluate(bars) {
    const i = bars.length - 1;
    const b = bars[i];
    // ... apni conditions yahan ...
    return null;
  },
};
