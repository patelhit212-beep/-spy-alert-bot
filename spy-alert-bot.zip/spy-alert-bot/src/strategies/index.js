// Yahan jo strategies list mein hain wahi chalengi.
import spy15mLiqGrab from './spy-15m-liquidity-grab.js';
// import exampleEmaVwapRsi from './example-ema-vwap-rsi.js';   // demo, band hai

export default [
  spy15mLiqGrab,
];
