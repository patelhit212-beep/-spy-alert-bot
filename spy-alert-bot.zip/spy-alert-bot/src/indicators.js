// Common indicators. Sab functions input jitni length ka array return karte hain
// (shuru mein jahan value nahi ban sakti wahan null).
import { nyPartsFromSec } from './time.js';

export function sma(values, period) {
  const out = new Array(values.length).fill(null);
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= period) sum -= values[i - period];
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

export function ema(values, period) {
  const out = new Array(values.length).fill(null);
  if (values.length < period) return out;
  const k = 2 / (period + 1);
  let prev = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

// Wilder RSI
export function rsi(closes, period = 14) {
  const out = new Array(closes.length).fill(null);
  if (closes.length <= period) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d >= 0) gain += d; else loss -= d;
  }
  gain /= period; loss /= period;
  out[period] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    gain = (gain * (period - 1) + Math.max(d, 0)) / period;
    loss = (loss * (period - 1) + Math.max(-d, 0)) / period;
    out[i] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  }
  return out;
}

// Wilder ATR
export function atr(bars, period = 14) {
  const out = new Array(bars.length).fill(null);
  const tr = bars.map((b, i) => i === 0 ? b.h - b.l
    : Math.max(b.h - b.l, Math.abs(b.h - bars[i - 1].c), Math.abs(b.l - bars[i - 1].c)));
  if (bars.length < period) return out;
  let prev = tr.slice(0, period).reduce((a, b) => a + b, 0) / period;
  out[period - 1] = prev;
  for (let i = period; i < bars.length; i++) {
    prev = (prev * (period - 1) + tr[i]) / period;
    out[i] = prev;
  }
  return out;
}

// Session VWAP — har naye trading din pe reset
export function vwap(bars) {
  const out = new Array(bars.length).fill(null);
  let day = null, pv = 0, vol = 0;
  bars.forEach((b, i) => {
    const d = nyPartsFromSec(b.t).date;
    if (d !== day) { day = d; pv = 0; vol = 0; }
    const tp = (b.h + b.l + b.c) / 3;
    pv += tp * b.v; vol += b.v;
    out[i] = vol > 0 ? pv / vol : tp;
  });
  return out;
}

// Pichhli N candles ka average volume (current candle ko chhod ke)
export function avgVolumeBefore(bars, i, n = 20) {
  const s = bars.slice(Math.max(0, i - n), i);
  if (!s.length) return 0;
  return s.reduce((a, b) => a + b.v, 0) / s.length;
}

// Aaj ki candles (session high/low, ORB wagera ke liye)
export function todaysBars(bars) {
  if (!bars.length) return [];
  const d = nyPartsFromSec(bars[bars.length - 1].t).date;
  return bars.filter(b => nyPartsFromSec(b.t).date === d);
}
