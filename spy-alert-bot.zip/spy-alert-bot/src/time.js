// New York (ET) time helpers — DST automatically handle hota hai.
const fmt = new Intl.DateTimeFormat('en-US', {
  timeZone: 'America/New_York',
  weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit',
  hour: '2-digit', minute: '2-digit', hour12: false,
});

export function nyParts(date = new Date()) {
  const p = Object.fromEntries(fmt.formatToParts(date).map(x => [x.type, x.value]));
  let hour = parseInt(p.hour, 10);
  if (hour === 24) hour = 0;
  return {
    weekday: p.weekday,
    date: `${p.year}-${p.month}-${p.day}`,
    hour,
    minute: parseInt(p.minute, 10),
    minOfDay: hour * 60 + parseInt(p.minute, 10),
  };
}

export const nyPartsFromSec = (sec) => nyParts(new Date(sec * 1000));

export const OPEN_MIN = 9 * 60 + 30;   // 9:30
export const CLOSE_MIN = 16 * 60;      // 16:00

export function isMarketWindow(n = nyParts()) {
  if (n.weekday === 'Sat' || n.weekday === 'Sun') return false;
  // close ke 10 min baad tak chalne do taaki last candle process ho jaye
  return n.minOfDay >= OPEN_MIN + 5 && n.minOfDay <= CLOSE_MIN + 10;
}

export function fmtET(sec) {
  const n = nyPartsFromSec(sec);
  const hh = String(n.hour).padStart(2, '0');
  const mm = String(n.minute).padStart(2, '0');
  return `${hh}:${mm} ET`;
}
