// Market data: Yahoo (free, no key) ya Alpaca (free key, IEX feed).
// Har bar: { t (unix sec, candle start), o, h, l, c, v }
import { nyParts, nyPartsFromSec, OPEN_MIN, CLOSE_MIN } from './time.js';

export const TF = {
  '5m':  { sec: 300,  yahoo: '5m',  range: '5d',  alpaca: '5Min',  days: 7 },
  '15m': { sec: 900,  yahoo: '15m', range: '10d', alpaca: '15Min', days: 14 },
  '1h':  { sec: 3600, yahoo: '60m', range: '1mo', alpaca: '1Hour', days: 40 },
};

async function fetchYahoo(symbol, tf) {
  const c = TF[tf];
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}` +
    `?interval=${c.yahoo}&range=${c.range}&includePrePost=false`;
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
  if (!res.ok) throw new Error(`Yahoo HTTP ${res.status}`);
  const j = await res.json();
  const r = j?.chart?.result?.[0];
  if (!r || !r.timestamp) throw new Error('Yahoo: no data');
  const q = r.indicators.quote[0];
  const bars = [];
  r.timestamp.forEach((t, i) => {
    if (q.open[i] == null || q.close[i] == null) return;
    bars.push({ t, o: q.open[i], h: q.high[i], l: q.low[i], c: q.close[i], v: q.volume[i] || 0 });
  });
  return bars;
}

async function fetchAlpaca(env, symbol, tf) {
  if (!env.ALPACA_KEY_ID || !env.ALPACA_SECRET) throw new Error('Alpaca keys missing');
  const c = TF[tf];
  const start = new Date(Date.now() - c.days * 86400000).toISOString();
  let url = `https://data.alpaca.markets/v2/stocks/${symbol}/bars?timeframe=${c.alpaca}` +
    `&start=${start}&limit=10000&feed=iex&adjustment=raw`;
  const bars = [];
  for (let page = 0; page < 5 && url; page++) {
    const res = await fetch(url, {
      headers: { 'APCA-API-KEY-ID': env.ALPACA_KEY_ID, 'APCA-API-SECRET-KEY': env.ALPACA_SECRET },
    });
    if (!res.ok) throw new Error(`Alpaca HTTP ${res.status}`);
    const j = await res.json();
    for (const b of j.bars || []) {
      bars.push({ t: Math.floor(Date.parse(b.t) / 1000), o: b.o, h: b.h, l: b.l, c: b.c, v: b.v });
    }
    url = j.next_page_token
      ? url.replace(/&page_token=[^&]*/, '') + `&page_token=${j.next_page_token}` : null;
  }
  // sirf regular session (Alpaca 1h bars clock-hour pe align hote hain)
  return bars.filter(b => {
    const n = nyPartsFromSec(b.t);
    return n.minOfDay >= (tf === '1h' ? 9 * 60 : OPEN_MIN) && n.minOfDay < CLOSE_MIN;
  });
}

// Sirf CLOSED candles return karta hai (chalti hui candle hata deta hai)
export async function getClosedBars(env, symbol, tf) {
  const bars = (env.DATA_PROVIDER === 'alpaca')
    ? await fetchAlpaca(env, symbol, tf)
    : await fetchYahoo(symbol, tf);
  if (!bars.length) return bars;
  const nowSec = Math.floor(Date.now() / 1000);
  const marketStillOpen = nyParts().minOfDay < CLOSE_MIN;
  const last = bars[bars.length - 1];
  if (marketStillOpen && last.t + TF[tf].sec > nowSec) bars.pop();
  return bars;
}
