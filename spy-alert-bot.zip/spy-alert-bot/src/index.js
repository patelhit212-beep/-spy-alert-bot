import strategies from './strategies/index.js';
import { getClosedBars } from './data.js';
import { nyParts, nyPartsFromSec, isMarketWindow } from './time.js';
import { sendTelegram, formatAlert } from './telegram.js';

const RANK = { Low: 0, Medium: 1, High: 2 };

async function runAll(env, { force = false } = {}) {
  const now = nyParts();
  if (!force && !isMarketWindow(now)) return [{ skipped: 'market band hai' }];

  const symbol = env.SYMBOL || 'SPY';
  const tfs = [...new Set(strategies.flatMap(s => s.timeframes))];
  const log = [];

  for (const tf of tfs) {
    let bars;
    try {
      bars = await getClosedBars(env, symbol, tf);
    } catch (e) {
      log.push({ tf, error: String(e) });
      await notifyErrorOncePerDay(env, now.date, tf, e);
      continue;
    }
    if (!bars.length) { log.push({ tf, info: 'no bars' }); continue; }

    const last = bars[bars.length - 1];
    if (!force && nyPartsFromSec(last.t).date !== now.date) {
      log.push({ tf, info: 'aaj ki koi closed candle nahi' });
      continue;
    }

    for (const s of strategies.filter(s => s.timeframes.includes(tf))) {
      // Ek candle pe ek hi baar check (duplicate alerts nahi)
      const seenKey = `seen:${s.id}:${tf}:${last.t}`;
      if (!force && await env.STATE.get(seenKey)) { log.push({ tf, s: s.id, info: 'already checked' }); continue; }
      if (!force) await env.STATE.put(seenKey, '1', { expirationTtl: 172800 });

      let sig = null;
      try { sig = s.evaluate(bars, { symbol, tf }); }
      catch (e) { log.push({ tf, s: s.id, error: String(e) }); continue; }

      if (!sig) { log.push({ tf, s: s.id, verdict: 'WAIT' }); continue; }
      if (RANK[sig.confidence] < RANK[s.minConfidence || 'Low']) {
        log.push({ tf, s: s.id, verdict: 'WAIT (low confidence)' });
        continue;
      }

      const countKey = `count:${s.id}:${tf}:${now.date}`;
      const count = parseInt(await env.STATE.get(countKey) || '0', 10);
      if (!force && s.maxPerDay && count >= s.maxPerDay) {
        log.push({ tf, s: s.id, info: 'daily limit reached' });
        continue;
      }

      await sendTelegram(env, formatAlert(symbol, tf, s, sig, last.t));
      if (!force) await env.STATE.put(countKey, String(count + 1), { expirationTtl: 172800 });
      log.push({ tf, s: s.id, verdict: `${sig.direction} ENTRY sent` });
    }
  }
  console.log(JSON.stringify(log));
  return log;
}

async function notifyErrorOncePerDay(env, date, tf, e) {
  const k = `err:${date}:${tf}`;
  if (await env.STATE.get(k)) return;
  await env.STATE.put(k, '1', { expirationTtl: 86400 });
  try { await sendTelegram(env, `⚠️ Data error (${tf}): ${String(e).slice(0, 200)}`); } catch {}
}

export default {
  async scheduled(event, env, ctx) {
    ctx.waitUntil(runAll(env));
  },

  async fetch(req, env) {
    const url = new URL(req.url);
    if (!env.ADMIN_KEY || url.searchParams.get('key') !== env.ADMIN_KEY) {
      return new Response('forbidden', { status: 403 });
    }
    if (url.pathname === '/test') {
      await sendTelegram(env, '✅ Test — SPY alert bot connected hai!');
      return new Response('Test message bhej diya');
    }
    if (url.pathname === '/run') {
      // force=1 → market band ho tab bhi chalao (testing ke liye)
      const log = await runAll(env, { force: url.searchParams.get('force') === '1' });
      return Response.json(log);
    }
    return new Response('SPY alert bot chal raha hai. /test ya /run use karo.');
  },
};
